import java.util.HashMap;
import software.amazon.awssdk.services.rekognition.model.Label;
import java.util.Scanner;

public class ParkITAI{
	
	private int[][] spaceMatrix;
	private int time;
	private int remainingCap;
	private int space;
	private int maxCap;
	
	
	public ParkITAI(int time, int number, int maxCap) { //constructor
		this.time = time;
		this.maxCap = maxCap;
		this.remainingCap = maxCap - number;
		this.space = remainingCap;
	}
	
	public int getTime(int time) {
		return time;
	}
	
	public int getRemain(int remainingCap) {
		return remainingCap;
	}
	
	public int getMaxCap(int maxCap) {
		return maxCap;
	}
	
	public int getSpace(int space) {
		return space;
	}
	
	public void Reservation(int time) {
		
		String misfortune = "Sorry, no spaces available at this time. Please try a different time.";
		String congrats = "We have reserved an available space for you to park. Thank you for booking with ParkIT AI!";
		spaceMatrix = new int[maxCap][25];
		if(availability(time) == true) {
			space--; //one less available space.
			System.out.println(congrats);
		} else {
			System.out.println(misfortune);
		}
		
		
	}
	
	public boolean availability(int time) {
		boolean result = false;
		for(int i = 0; i < maxCap; i++) {
			if(spaceMatrix[i][time] == 0) {
				spaceMatrix[i][time] = 1;
				result = true;
				break;
			}
			if(spaceMatrix[i][time] == 1) {
				result = false;
			}
		}
		return result;
	}
	
/*	public void reOpenSpace(Integer i) {
		spaceMatrix.remove(i);
		if(space < maxCap) {
			space++; //adds one more available space
		}
	}
*/	
	
	
	
	
	
}
